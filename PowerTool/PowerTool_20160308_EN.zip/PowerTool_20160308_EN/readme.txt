PowerTool is a free anti-virus&rootkit utility.It offers you the ability to detect, 
analyze and fix various kernel structure modifications and gives you a wide scope of the kernel.
With its help,you can easily spot and remove malwares hidden from normal software.

PowerTool currently supports the following Windows 32-bit versions:
for Windows PE/Safe Mode/Windows XP/Windows 2003 Server/Vista/Windows 2008 Server/Windows7 SP1/Windows8/Windows8.1/Windows 10 build 10586


Contact me :
Email:	ithurricane@gmail.com
QQ:	1371872626
about.me: http://about.me/ithurricanept
linkin  : https://www.linkedin.com/in/powertool
twitter : http://twitter.com/ithurricanept
google+ : ithurricane@gmail.com

2016-03-08 PowerTool x64 V2.0
  Add:
    1. Add Hardware Detection(CPU/Motherboard/Memory(support DDR4)/HardDisk(support SSD)
	/VideoCard/Monitor/AudioCard/NetworkCard/USB Devices/Battery/Temperature etc.).
    2. Add GPT Check(If use Legacy BIOS, still check MBR).
  
 Modify:
    1. Modify after the sorting process, color turns blue BUG.


2015-12-22 PowerTool x64 V1.9/x86 V4.8(Merry Christmas && Happy New Year)
  
 Modify:
    1. Modify BSOD bug when kill process(64bit).
    2. Modify parse register BUG(32/64bit).
    3. Modify crash bug when view ShadowSSDT(64bit).
    4. Modufy enum task scheduler BUG(64bit).
    5. Modify a logic bug when suspend process(32/64bit).
    6. No longer generate Temp/Temp32/Temp64 temporary folders, and don't generate any temporary files either(64bitbit).

2015-12-09 PowerTool x64 V1.8
  Add:
  1.Integrated delete file && Online scan virus to right-click menu.
  2. Add detect Code Inject.(When detect it, suspend the thread)
  
 Modify:
    1. Modify kill process Bug.
    2. Modify suspend thread Bug.


PowerTool V4.7&&V1.7 2015-12-07
Update��
1. support Windows 10 Build 10586(32/64bit)
2. Add view process commandline and process type (distinguishing normal process and service process).(64bit)
3. Add disable/enable task scheduler.(32/64bit)
4. Enhanced selfprotect.(64bit)
5. Change ico.(32/64bit)


2014-02-08 PowerTool x86 V4.6
  Add:
1. Add view process commandline and process type (distinguishing normal process and service process)
2. Check whether you need to restart after Windows Update
  
 Modify:
    1. Improved support for win8.1 (including process timers, detection kernel entry point, etc.)
    2. can parse multiple ADS stream files of one file.
    3. Improved delete directory (recursively delete).
    4. Modify the view WFP network filtering crash BUG.
    5. Remove the self-protection warning dialog when start PowerTool.
    6. Restore the online update feature.

2013-12-08 PowerTool V4.5(twitter : http://twitter.com/ithurricanept && google+ : ithurricane@gmail.com)
  Add:
1. Support Windows8.1
2. Add view and remove WFP Filter
3. Add view NDIS MiniDriver and MiniPort
  
 Modify:
1. Fix bug of enum process on windows2003.
2. Fix bug of view task scheduler.
3. Replace Filterbit to Jotti as online scan engine.

2012-10-27 PowerTool V4.3(twitter : http://twitter.com/ithurricanept && google+ : ithurricane@gmail.com)
  Add:
1. Support Windows8 build 9200 
  
 Modify:
1. Enhance progress bar, prevent wrong operation.
2. Enhance View Service.
3. Fix some small BUGs.


2011-12-24 PowerTool V4.2(twitter : http://twitter.com/ithurricane && google+ : ithurricane@gmail.com)
  Add:
1. Detect VBR Bootkit(such as Rootkit.Win32.Cidox) 
2. Detecting/Memory Forging Attempt by a Rootkit(such as TDL4 variants) 
  
 Modify:
1. Enhance Detect IDT Hook
2. Analyze Disk/Register File without load Driver
3. Fix some Offline Analyze BUG.


2011-10-01 PowerTool V4.1
  Add:
1. Detect Mebromi Bios Rootkit. 
  
 Modify:
1. Modified some the program crash BUG
2. Modified could not load the driver after program crash.
3. Fix some Offline Analyze BUG.

2011-09-02 PowerTool V4.0.2
  Add:
1. Detect Infected System Drivers. 
  
 Modify:
1. Some Improvements For ZeroAccess Rootkit.


2011-08-13 PowerTool V4.0
  Add:
1. Detect Debug Registers Hook. 
1. Detect Sysenter Hook(inline hook). 
  
 Modify:
1. Improve enum kernel module speed
2. Fix Disassembly of the MBR Code

2011-07-17 PowerTool V3.9
  Add:
    1.Detect TDSS/TDL4 without unhook anything 
    2. Detection kernel callback table hook
    3. Add splash screen
    4. Add Disk Trace
  
 Modify:
    1. Can detect multi-level jump Hook
    2. Enhance the detection of hidden module
    3. Enhance the detection of Kernel Modules

2011-06-23 PowerTool V3.8
  Add:
    1. Manager the hidden account and the clone account
    2. Enhance detection mbr code
  
 Modify:
    1. Can enumerate <without HOOK, let the Task Manager, XueTr, 360 Process Manager can not kill the process>  hidden thread in the text
    2. Enhanced self-protection, and is set to reminding at start
    3. Load drivers by random driver Name, prevent the virus stop to load 
    4. Improve the stability of kill process
    5. Can rename the deformity directory 
    6. Modify some process can not display the username BUG 
    7. Can use the keyboard line, Refresh module list 
    8. Enhance the detection of Object Hook 
    9. Increase rogue shortcuts detect items 
    10. When MBR normal, prompts the user to back up the MBR 
    11. Online update, unload the driver and close the program, to avoid the mix of old and new versions

2011-06-09 PowerTool V3.7.2
    1. Fixed part of the machine Blue Screen BUG
    2. Enhance Strength of File Rename (Can be directly rename the file be opened by another process)
    3. Add rename the folder
    4. Fix the suspension of the thread
    5. can not load the driver can also be part of the operation of the process


2011-06-06 PowerTool V3.7.1 Dragon Boat Festival Version
Modify��
    1. Fixed a bug that causes blue screen
    2. Change View Network Connection Speed


2011-06-05
Added��
    1. View Network Connection
    2. Detection of the Kernel IAT/EAT Hook
    3. File Rename

Modify��
    1. Fix Enumerate Kernel Module BUG
    2. Enhance the file unlock 
    3. Enhance the Detection of Startup
    4. Fix pause and resume the thread BUG
    5. Fix Multi-Disk restore MBR BUG
    6. Fix Display Ghost3 Virus Process Path BUG
