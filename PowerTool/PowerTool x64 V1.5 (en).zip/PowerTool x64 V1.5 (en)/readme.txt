PowerTool is a free anti-virus&rootkit utility.It offers you the ability to detect, 
analyze and fix various kernel structure modifications and gives you a wide scope of the kernel.
With its help,you can easily spot and remove malwares hidden from normal software.

PowerTool currently supports the following Windows 64-bit versions:
for Vista/Windows 2008 Server/Windows7/Windows 8/Windows 8.1 (64bit)

Donation:
PayPal Account : ithurricane@gmail.com

Contact me:
Email:	ithurricane@gmail.com
QQ:	1371872626
MSN:	ithurricane@hotmail.com
twitter : http://twitter.com/ithurricanept
google+ : ithurricane@gmail.com


2014-01-20 PowerTool x64 V1.5  
 Modify:
    1. Modify bug of only get one ADS stream file when parsing NTFS
    Add multiple stream file：
    echo "this is a stream file" > a.txt:stream.txt1;echo "this is a stream file" > a.txt:stream.txt2
    2. Modify analyze registry file bug.
    3. Modify bug of file not exist and parsing command line parameters
    4. Modify bug of can't get ShadowSsdt hook on Win8/Win8.1
    5. Modify crash bug when view [WFP(Windows Filtering Platform)]
    6. Add PayPal Donation(PayPal Account : ithurricane@gmail.com, thank you for support)
	

2013-12-02 PowerTool x64 V1.3
  Add:
    1.Add view and remove WFP(Windows Filtering Platform).
    2.Add Support Windows 8/Windows 8.1. 
    3.Add simple self-protect.
  
 Modify:
    1. Enhance kill process 
    2. Modify bug of process's user timer.
    3. Modify bug of view digital signature.
    4. Modify bug of view task scheduler.
    5. As the online scanner site Filterbit invalid, replacing it uploaded to Jotti.


2012-07-29 PowerTool x64 V1.2
  Add:
    1.Add View Filter Driver
    2.Add View NetConnects
    3.Add View Process's Timer
    4.Add Support Windows 8 Release Preview Build 8400 
  
 Modify:
    1. Enhance View Service 
    2. Modify Bug of Detection keyboard spyware